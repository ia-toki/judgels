#include <cstdio>

char s[7];

int main() {
	scanf("%s", s);
	printf("%s\n", s);
}
