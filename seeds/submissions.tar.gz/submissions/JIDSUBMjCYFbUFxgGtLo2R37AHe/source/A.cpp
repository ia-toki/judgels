#include <cstdio>

int main() {
	int a;
	scanf("%d", &a);
	printf("%dd\n", a+a);
}
