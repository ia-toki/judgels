#include <cstdio>

char s[100];

int main() {
	scanf("%s", s);
	printf("%s\n", s);
}
