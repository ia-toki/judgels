#include <cstdio>
#include <cstring>

char s[1005];

int main() {
	scanf("%s", s);

	if (strlen(s) <= 5) {
		printf("%s\n", s);
	}
}
