#include <cstdio>

char s[1005];

int main() {
	scanf("%s", s);
	printf("%s\n", s);
}
