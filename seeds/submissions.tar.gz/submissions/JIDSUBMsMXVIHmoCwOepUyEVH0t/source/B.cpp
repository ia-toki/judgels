#include <cstdio>
#include <cstring>

char s[100];

int main() {
	scanf("%s", s);
	if (strlen(s) <= 5) {
		printf("%s\n", s);
	}
}
